import 'package:flutter/material.dart';
import 'package:hannanth/Screens/new_email_screen.dart';
import 'package:hannanth/components/common_button.dart';
import 'package:hannanth/components/common_textfeild.dart';

class ChangeEmailScreen extends StatefulWidget {
  const ChangeEmailScreen({super.key});

  @override
  State<ChangeEmailScreen> createState() => _ChangeEmailScreenState();
}

class _ChangeEmailScreenState extends State<ChangeEmailScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16.0),
        child:  Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("Change email",
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 18.0,
                    fontWeight: FontWeight.w500)),
            const SizedBox(height: 10.0),
            const Text("Enter old email address",
                style: TextStyle(
                    color: Color(0xff002a53),
                    fontSize: 14.0,
                    fontWeight: FontWeight.w500)),
            const CommonTextField(hintText: "Enter old email address"),
            const SizedBox(height: 20.0),
            CommonButton(
              buttonText: "Submit",
              onClick: () => Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => const NewEmailScreen(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
