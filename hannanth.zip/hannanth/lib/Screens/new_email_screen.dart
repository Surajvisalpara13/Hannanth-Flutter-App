import 'package:flutter/material.dart';
import 'package:hannanth/components/common_textfeild.dart';

import '../components/common_button.dart';

class NewEmailScreen extends StatefulWidget {
  const NewEmailScreen({super.key});

  @override
  State<NewEmailScreen> createState() => _NewEmailScreenState();
}

class _NewEmailScreenState extends State<NewEmailScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("Change email",
                style: TextStyle(
                    color: Colors.black,
                    fontSize: 18.0,
                    fontWeight: FontWeight.w500)),
            const SizedBox(height: 10.0),
            /////////////////1
            const Text("Enter old email address",
                style: TextStyle(
                    color: Color(0xff002a53),
                    fontSize: 14.0,
                    fontWeight: FontWeight.w500)),
            const CommonTextField(hintText: "Enter old email address"),
            const SizedBox(height: 15.0),
            /////////////////2
            const Text("Enter new email address",
                style: TextStyle(
                    color: Color(0xff002a53),
                    fontSize: 14.0,
                    fontWeight: FontWeight.w500)),
            const CommonTextField(hintText: "Enter new email address"),

            const SizedBox(height: 15.0),
            /////////////////3
            const Text("Confirm email address",
                style: TextStyle(
                    color: Color(0xff002a53),
                    fontSize: 14.0,
                    fontWeight: FontWeight.w500)),
            const CommonTextField(hintText: "Confirm email address"),
            const SizedBox(height: 15.0),
            CommonButton(
              buttonText: "Submit",
              onClick: (){},
            ),
          ],
        ),
      ),
    );
  }
}
