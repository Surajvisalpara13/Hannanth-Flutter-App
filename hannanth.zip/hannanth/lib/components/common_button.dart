import 'package:flutter/material.dart';

class CommonButton extends StatefulWidget {
  final String buttonText;
  final dynamic onClick;

  const CommonButton({super.key, required this.buttonText, this.onClick});

  @override
  State<CommonButton> createState() => _CommonButtonState();
}

class _CommonButtonState extends State<CommonButton> {
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        SizedBox(
          width: MediaQuery.of(context).size.width / 2,
          height: 50.0,
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xff002a53),
              padding: const EdgeInsets.all(0.0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(25.0),
              ),
            ),
            child: Text(
              widget.buttonText,
              style: const TextStyle(fontSize: 20.0, color: Colors.white),
            ),
            onPressed: widget.onClick
          ),
        ),
      ],
    );
  }
}
