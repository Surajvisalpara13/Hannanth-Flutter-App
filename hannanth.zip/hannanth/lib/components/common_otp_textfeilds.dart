import 'package:flutter/material.dart';

class CommonOtpTextField extends StatefulWidget {
  final dynamic controller;
  final dynamic focusNode;
  final dynamic onChange;

  const CommonOtpTextField({
    Key? key,
    this.controller,
    this.focusNode,
    this.onChange,
  }) : super(key: key);

  @override
  State<CommonOtpTextField> createState() => _CommonOtpTextFieldState();
}

class _CommonOtpTextFieldState extends State<CommonOtpTextField> {
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 4.0),
      alignment: Alignment.center,
      height: 35,
      width: 35,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(5.0),
        border: Border.all(color: const Color(0xff002a53),width: 1),
        color: Colors.transparent,
        // boxShadow: [commonShadow()],
      ),
      child: TextFormField(
        cursorWidth: 0,
        controller: widget.controller,
        focusNode: widget.focusNode,
        style: const TextStyle(color: Color(0xff002a53), fontSize: 18.0),
        keyboardType: TextInputType.number,
        maxLength: 1,
        decoration: const InputDecoration(
          border: InputBorder.none,
          counterText: '',
        ),
        textAlign: TextAlign.center,
        onChanged: widget.onChange,
      ),
    );
  }
}
