import 'package:flutter/material.dart';
import 'package:hannanth/components/common_button.dart';
import 'package:hannanth/components/otp_component.dart';

class CommonTextField extends StatefulWidget {
  final String hintText;
  const CommonTextField({super.key, required this.hintText});

  @override
  State<CommonTextField> createState() => _CommonTextFieldState();
}

class _CommonTextFieldState extends State<CommonTextField> {
  @override
  Widget build(BuildContext context) {
    return TextField(
      decoration: InputDecoration(
        hintText: widget.hintText,
        hintStyle: const TextStyle(fontSize: 12.0, color: Colors.grey),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(5),
          borderSide: const BorderSide(
            color: Colors.black,
            width: 1,
            style: BorderStyle.solid,
          ),
        ),
        suffixIcon: Container(
          margin: const EdgeInsets.all(8),
          child: ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xff002a53),
              padding: const EdgeInsets.all(0.0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(5.0),
              ),
            ),
            child: const Text(
              "GET OTP",
              style: TextStyle(fontSize: 10.0, color: Colors.white),
            ),
            onPressed: () {
              showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      content: SizedBox(
                        height: 150.0,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            const Text("Enter OTP",
                                style: TextStyle(
                                    color: Color(0xff002a53),
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.w500)),
                            const OtpComponent(),
                            CommonButton(buttonText: "Verify",onClick: (){
                              Navigator.pop(context);
                            }),
                          ],
                        ),
                      ),
                    );
                  });
            },
          ),
        ),
      ),
    );
  }
}
