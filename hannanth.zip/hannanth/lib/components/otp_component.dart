import 'package:flutter/material.dart';
import 'package:hannanth/components/common_otp_textfeilds.dart';


class OtpComponent extends StatefulWidget {
  const OtpComponent({Key? key}) : super(key: key);

  @override
  State<OtpComponent> createState() => _OtpComponentState();
}

class _OtpComponentState extends State<OtpComponent> {
  TextEditingController? otp1Controller = TextEditingController();
  TextEditingController? otp2Controller = TextEditingController();
  TextEditingController? otp3Controller = TextEditingController();
  TextEditingController? otp4Controller = TextEditingController();
  TextEditingController? otp5Controller = TextEditingController();
  TextEditingController? otp6Controller = TextEditingController();

  FocusNode? otp1FocusNode = FocusNode();
  FocusNode? otp2FocusNode = FocusNode();
  FocusNode? otp3FocusNode = FocusNode();
  FocusNode? otp4FocusNode = FocusNode();
  FocusNode? otp5FocusNode = FocusNode();
  FocusNode? otp6FocusNode = FocusNode();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        CommonOtpTextField(
          controller: otp1Controller,
          focusNode: otp1FocusNode,
          onChange: (value) {
            if (value.length == 1) {
              otp1FocusNode!.unfocus();
              FocusScope.of(context).requestFocus(otp2FocusNode);
            }
          },
        ),
        CommonOtpTextField(
          controller: otp2Controller,
          focusNode: otp2FocusNode,
          onChange: (value) {
            if (value.length == 1) {
              otp2FocusNode!.unfocus();
              FocusScope.of(context).requestFocus(otp3FocusNode);
            } else {
              FocusScope.of(context).previousFocus();
            }
          },
        ),
        CommonOtpTextField(
          controller: otp3Controller,
          focusNode: otp3FocusNode,
          onChange: (value) {
            if (value.length == 1) {
              otp3FocusNode?.unfocus();
              FocusScope.of(context).requestFocus(otp4FocusNode);
            } else {
              FocusScope.of(context).previousFocus();
            }
          },
        ),

        CommonOtpTextField(
          controller: otp4Controller,
          focusNode: otp4FocusNode,
          onChange: (value) {
            if (value.length == 1) {
              otp4FocusNode?.unfocus();
              FocusScope.of(context).requestFocus(otp5FocusNode);
            } else {
              FocusScope.of(context).previousFocus();
            }
          },
        ),
        CommonOtpTextField(
          controller: otp5Controller,
          focusNode: otp5FocusNode,
          onChange: (value) {
            if (value.length == 1) {
              otp1FocusNode!.unfocus();
            } else {
              FocusScope.of(context).previousFocus();
            }
          },
        ),
      ],
    );
  }
}
